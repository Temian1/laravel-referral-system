# Changelog

All notable changes to the "jijunair/laravel-referral" package will be documented in this file.

## [1.0.0] - 2023-07-14

### Added
- Initial release of the "jijunair/laravel-referral" package.

[1.0.0]: https://github.com/jijunair/laravel-referral/releases/tag/v1.0.0
